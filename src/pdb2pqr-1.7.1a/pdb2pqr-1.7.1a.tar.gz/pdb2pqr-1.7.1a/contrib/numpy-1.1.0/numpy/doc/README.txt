Very complete documentation is available from the primary developer of
NumPy for a small fee.  After a brief period, that documentation
will become freely available.  See http://www.trelgol.com for
details. The fee and restriction period is intended to allow people
and to encourage companies to easily contribute to the development of
NumPy.

This directory will contain all public documentation that becomes available. 

Very good documentation is also available using Python's (and
especially IPython's) own help system.  Most of the functions have
docstrings that provide usage assistance.



