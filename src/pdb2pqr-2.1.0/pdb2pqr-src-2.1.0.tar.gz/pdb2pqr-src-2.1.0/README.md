apbs-pdb2pqr
============

This is the home for the [APBS and PDB2PQR software](http://www.poissonboltzmann.org). 

Please see the [user guide](doc/userguide.html) for the documentation index and the [COPYING file](COPYING) for license information.

Please see [programmer's guide](doc/programmerguide.html) for information on working with the PDB2PQR code. 
