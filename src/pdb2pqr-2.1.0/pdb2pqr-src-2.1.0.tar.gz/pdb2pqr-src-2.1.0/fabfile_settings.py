
#Host address of OSX machine to build on.
#osx_host = 'osx.host'

#Host address of Linux machine to build on.
#linux_host = 'linux.host'

#Run tests after build.
#run_tests=True


#The remaining setting are for running "install_on_deployed"
#APBS install location (Same as the APBS build setting)
#APBS='/Users/name/bin/apbs'

#URL (Same as the URL build setting)
#URL='http://host/pdb2pqr'

#Prefix (Same as the PREFIX build setting)
#PREFIX='/Users/name/pdb2pqr/'

#OPAL URL, if any. (Same as the OPAL build setting)
#OPAL='http://nbcr-222.ucsd.edu/opal2/services/pdb2pqr_2.0.0'

#ABPS OPAL URL, if any. (Same as the APBS_OPAL build setting)
#APBS_OPAL='http://nbcr-222.ucsd.edu/opal2/services/apbs_1.3'