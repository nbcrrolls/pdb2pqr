#
# ligandclean routines
#